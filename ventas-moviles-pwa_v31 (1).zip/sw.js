// Service Worker — Ventas Móviles by pejaca
const CACHE = 'ventas-moviles-v31';
const ASSETS = [
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

// Instalar: cachear archivos base
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

// Activar: limpiar caches viejos
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch: red primero, cache como respaldo (para funcionar offline)
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  // No cachear Google Drive ni el inicio de sesión de Google (datos privados y siempre frescos)
  const host = new URL(e.request.url).hostname;
  if (host === 'www.googleapis.com' || host === 'accounts.google.com' || host === 'oauth2.googleapis.com') return;
  e.respondWith(
    fetch(e.request)
      .then(res => {
        const clone = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
        return res;
      })
      .catch(() => caches.match(e.request).then(r => r || caches.match('./index.html')))
  );
});
